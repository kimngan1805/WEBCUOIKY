let listProductHTML = document.querySelector('.listProduct');
let listproducts2HTML = document.querySelector('.listproducts2');
let listproducts3HTML = document.querySelector('.listproducts3');
let listCartHTML = document.querySelector('.listCart');
let iconCart = document.querySelector('.icon-cart');
let iconCartSpan = document.querySelector('.icon-cart span');
let body = document.querySelector('body');
let closeCart = document.querySelector('.close');
let searchForm = document.getElementById('search-form');
let searchInput = document.getElementById('search-input');
let products = [];
let products2 = [];
let products3 = [];
let cart = [];

iconCart.addEventListener('click', () => {
    body.classList.toggle('showCart');
});
closeCart.addEventListener('click', () => {
    body.classList.toggle('showCart');
});

const addDataToHTML = (productList, listElement) => {
    listElement.innerHTML = '';
    if (productList.length > 0) {
        productList.forEach(product => {
            let newProduct = document.createElement('div');
            newProduct.dataset.id = product.id;
            newProduct.classList.add('item');
            newProduct.innerHTML = 
            `<img src="${product.image}" alt="">
            <h2>${product.name}</h2>
            <div class="price">${product.price}.000</div>
            <button class="addCart">THÊM VÀO GIỎ</button>`;
            listElement.appendChild(newProduct);
        });
    }
};

listProductHTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if (positionClick.classList.contains('addCart')) {
        let id_product = positionClick.parentElement.dataset.id;
        addToCart(id_product);
    }
});

listproducts2HTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if (positionClick.classList.contains('addCart')) {
        let id_product = positionClick.parentElement.dataset.id;
        addToCart(id_product);
    }
});

listproducts3HTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if (positionClick.classList.contains('addCart')) {
        let id_product = positionClick.parentElement.dataset.id;
        addToCart(id_product);
    }
});

const addToCart = (product_id) => {
    let positionThisProductInCart = cart.findIndex((value) => value.product_id == product_id);
    if (cart.length <= 0) {
        cart = [{
            product_id: product_id,
            quantity: 1
        }];
    } else if (positionThisProductInCart < 0) {
        cart.push({
            product_id: product_id,
            quantity: 1
        });
    } else {
        cart[positionThisProductInCart].quantity += 1;
    }
    addCartToHTML();
    addCartToMemory();
};

const addCartToMemory = () => {
    localStorage.setItem('cart', JSON.stringify(cart));
};

const addCartToHTML = () => {
    listCartHTML.innerHTML = '';
    let totalQuantity = 0;
    if (cart.length > 0) {
        cart.forEach(item => {
            totalQuantity += item.quantity;
            let newItem = document.createElement('div');
            newItem.classList.add('item');
            newItem.dataset.id = item.product_id;

            let info = products.find(p => p.id == item.product_id) ||
                       products2.find(p => p.id == item.product_id) ||
                       products3.find(p => p.id == item.product_id);

            listCartHTML.appendChild(newItem);
            newItem.innerHTML = `
            <div class="image">
                <img src="${info.image}">
            </div>
            <div class="name">
                ${info.name}
            </div>
            <div class="totalPrice">$${info.price * item.quantity}</div>
            <div class="quantity">
                <span class="minus"><</span>
                <span>${item.quantity}</span>
                <span class="plus">></span>
            </div>
            `;
        });
    }
    iconCartSpan.innerText = totalQuantity;
};

listCartHTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if (positionClick.classList.contains('minus') || positionClick.classList.contains('plus')) {
        let product_id = positionClick.parentElement.parentElement.dataset.id;
        let type = 'minus';
        if (positionClick.classList.contains('plus')) {
            type = 'plus';
        }
        changeQuantityCart(product_id, type);
    }
});

const changeQuantityCart = (product_id, type) => {
    let positionItemInCart = cart.findIndex((value) => value.product_id == product_id);
    if (positionItemInCart >= 0) {
        switch (type) {
            case 'plus':
                cart[positionItemInCart].quantity += 1;
                break;
            default:
                cart[positionItemInCart].quantity -= 1;
                if (cart[positionItemInCart].quantity <= 0) {
                    cart.splice(positionItemInCart, 1);
                }
                break;
        }
    }
    addCartToHTML();
    addCartToMemory();
};

const initApp = () => {
    fetch('products.json')
    .then(response => response.json())
    .then(data => {
        products = data;
        addDataToHTML(products, listProductHTML);

        if (localStorage.getItem('cart')) {
            cart = JSON.parse(localStorage.getItem('cart'));
            addCartToHTML();
        }
    });

    fetch('products2.json')
    .then(response => response.json())
    .then(data => {
        products2 = data;
        addDataToHTML(products2, listproducts2HTML);
    });

    fetch('products3.json')
    .then(response => response.json())
    .then(data => {
        products3 = data;
        addDataToHTML(products3, listproducts3HTML);
    });
};

initApp();

// Sự kiện tìm kiếm
searchForm.addEventListener('submit', (event) => {
    event.preventDefault();
    let searchTerm = searchInput.value.toLowerCase();
    let allProducts = [...products, ...products2, ...products3];

    let filteredProducts = allProducts.filter(product => product.name.toLowerCase().includes(searchTerm));

    let listProductHTML = document.querySelector('.listProduct');
    let listproducts2HTML = document.querySelector('.listproducts2');
    let listproducts3HTML = document.querySelector('.listproducts3');

    if (filteredProducts.length > 0) {
        addDataToHTML(filteredProducts, listProductHTML);
        addDataToHTML([], listproducts2HTML);
        addDataToHTML([], listproducts3HTML);
    } else {
        listProductHTML.innerHTML = '<p>Không tìm thấy sản phẩm.</p>';
        listproducts2HTML.innerHTML = '';
        listproducts3HTML.innerHTML = '';
    }
    
    // Ẩn các label khi hiển thị kết quả tìm kiếm
    document.querySelectorAll('.logo').forEach(label => label.style.display = 'none');
});
